__turbopack_load_page_chunks__("/_error", [
  "static/chunks/14_feb75mkwzl.js",
  "static/chunks/3u-ya155zwc4m.js",
  "static/chunks/turbopack-3jvzcl_2a1-b-.js"
])
