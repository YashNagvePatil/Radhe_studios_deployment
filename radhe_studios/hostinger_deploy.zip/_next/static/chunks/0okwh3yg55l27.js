__turbopack_load_page_chunks__("/Info", [
  "static/chunks/39bkczokjalnp.js",
  "static/chunks/2a2ragg8xv7ti.js",
  "static/chunks/2k407y1ayryhq.js",
  "static/chunks/3u-ya155zwc4m.js",
  "static/chunks/turbopack-0uwm405ymp5ip.js"
])
