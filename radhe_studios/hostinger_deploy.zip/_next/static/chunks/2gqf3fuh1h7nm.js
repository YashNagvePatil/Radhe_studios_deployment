__turbopack_load_page_chunks__("/Clients", [
  "static/chunks/1kxdlzn4afbya.js",
  "static/chunks/2a2ragg8xv7ti.js",
  "static/chunks/2k407y1ayryhq.js",
  "static/chunks/3u-ya155zwc4m.js",
  "static/chunks/0xrlfnh3ka6_a.js",
  "static/chunks/turbopack-0cfdg5-ka8ee5.js"
])
