__turbopack_load_page_chunks__("/_app", [
  "static/chunks/25i2obum49mu6.js",
  "static/chunks/3u-ya155zwc4m.js",
  "static/chunks/turbopack-2tcpte911uisr.js"
])
