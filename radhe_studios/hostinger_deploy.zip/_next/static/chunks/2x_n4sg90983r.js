__turbopack_load_page_chunks__("/HeroSection", [
  "static/chunks/44pr6cleww0bm.js",
  "static/chunks/3u-ya155zwc4m.js",
  "static/chunks/turbopack-2tka64iz35lur.js"
])
