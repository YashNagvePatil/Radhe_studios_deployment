__turbopack_load_page_chunks__("/OwrWork", [
  "static/chunks/2mv6ls_csgw40.js",
  "static/chunks/3u-ya155zwc4m.js",
  "static/chunks/2k407y1ayryhq.js",
  "static/chunks/turbopack-0y6v5jufuz_1e.js"
])
