self.__BUILD_MANIFEST = {
  "/Clients": [
    "static/chunks/2gqf3fuh1h7nm.js"
  ],
  "/HeroSection": [
    "static/chunks/2x_n4sg90983r.js"
  ],
  "/Info": [
    "static/chunks/0okwh3yg55l27.js"
  ],
  "/OwrWork": [
    "static/chunks/0zkun0ti8egn2.js"
  ],
  "/_error": [
    "static/chunks/3-fry2t1rhxan.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/Clients",
    "/HeroSection",
    "/Info",
    "/OwrWork",
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()